/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.truongnguyen.mathutil.core;

/**
 *
 * @author LENOVO
 */
public class MathUtil {
    
    // trong class này cung cấp cho ai đó nhiều hàm xử lí toán học
    // clone class Math của JDK
    // hàm thư viện xài chung cho ai đó, không cần lưu lại trạng thái/giá trị
    // chọn thiết kế là hàm static
    
    // hàm tính giai thừa
    // n!=1.2.3.4.....
    // không có giai thừa cho số âm
    // 0!=1
    // giai thừa hàm đồ thị dốc đứng, tăng nhanh về giá trị
    // 20! là 18 con số 0, vừa kịp đủ cho kiểu long của JAVA
    // 21! sẽ bị tràn
    // bài này quy ước tính n! trong khoảng 0 ->20
//    public static long getFactorial(int n){
//        if(n<0 || n> 20){
//            throw new IllegalArgumentException("Invalid argument. N must be between 0 -> 20");           
//        }
//        
//        if(n==0 || n==1){
//            return 1; // giá trị đặc biệt
//        }
//        
//        long product=1; //tích
//        for (int i = 2; i <= n; i++) {
//            product *= i;
//        }
//        return product;
        
        // Đệ quy là việc gọi lại chính mình với 1 quy mô khác
        // VD: 6! = 6x 5!
        // 5! = 5 x 4!
        // 4! = 4 x 3!
        // 3! = 3 x 2!
        // 2!=  2 x 1! // điểm dừng
        // quy ước 1! = 0! = 1
        
        //deal n! = n x (n-1)!
        public static long getFactorial(int n){
        if(n <0 || n> 20){
            throw new IllegalArgumentException("Invalid argument. N must be between 0 -> 20");
        }
        
        if(n==0 || n==1){
            return 1; // giá trị đặc biệt
        }
        return n * getFactorial(n-1); // công thức đệ quy
        
    }
}
