/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.truongnguyen.mathutil.test.core;

import com.truongnguyen.mathutil.core.MathUtil;
import org.junit.Assert;
import org.junit.Test;


/**
 *
 * @author LENOVO
 */
public class MathUtilityTest {
    // đây là class sẽ dùng các hàm của thư viện/framework JUnit
    // để kiểm thử / kiểm tra code chính- hàm tính giai thừa
    // viết code để test code bên kia
    
    // có nhiều quy tắc đặt tên hàm kiểm thử
    // nhưng thường sẽ là nói lên mục đích các case/ tình huống kiểm thử
    
    // hàm dưới là tình huống test thành công, trả về đúng
    // ta sẽ dùng hàm kiểu well
    
    //@Test JUnit sẽ phối hợp vs JVM để chạy hàm
    //@Test public static void main()
    //Có nhiều @Test ứng vs nhiều case khác nhau để kiểm thử hàm tính giai thừa
    @Test
    public void testGetFactorialGivenRightArgumentReturnsWell(){
        int n=0;
        long expected=1; // hy vọng 0!=1
         // gọi hàm cần test bên core/app chính/code chính
        long actual=MathUtil.getFactorial(n);
        
        // so sánh expected vs actual, dùng framework
        Assert.assertEquals(expected, actual);
        // hàm giúp so sánh 2 giá trị nào đó là giống nhau không
        // nếu giống nhau -> màu xanh
        // nếu khác nhau -> màu đỏ
        
        
        // có thể gộp thêm vài case thành công nữa 
        Assert.assertEquals(1, MathUtil.getFactorial(1));
        Assert.assertEquals(2, MathUtil.getFactorial(2));// muốn 2!=2
        Assert.assertEquals(6, MathUtil.getFactorial(3));// muốn 3!=6
        Assert.assertEquals(120, MathUtil.getFactorial(5)); // báo lỗi do 5!= 120
    }

    
    // hàm getF() thiết kế có 2 tình huống xử lí
    //1. đưa data tử tế trong 0-> 20 tính đúng được n!
    //2. đưa vào data sai -> thiết kế hàm sẽ ném ra ngoại lệ
    // kì vọng ngoại lệ xuất hiện
    
    // nếu hàm nhận vào n<0 hoặc n> 20 và hàm ném ra ngoại lệ thì -> hàm đúng
    
    // Test case:
    // input: -5
    // expected: IllegalArgumentException xuất hiện
    // assertEquals() ko thể dùng để so sánh 2 ngoại lệ
    //       equals() là bằng nhau hay ko trên value
    
    
    // Màu đỏ do hàm đúng ném ngoại lệ nhưng không phải ngoại lệ kì vọng chứ không phải hàm ném sai
    @Test(expected = IllegalArgumentException.class)
    public void testGetFactorialGivenWrongtArgumentThrowsException(){
        MathUtil.getFactorial(-5); // hàm @Test hay hàm getF() này chạy sẽ phải ném về ngoại lệ NumberFormat
    
    }
    
    // cách khác để bắt ngoại lệ xuất hiện, viết tự nhiên hơn
    // Lambda Expression
    // hàm ném về ngoại lệ nếu nhận vào -5
    @Test
    public void testGetFactorialGivenWrongtArgumentThrowsExceptionLambdaVersion(){
       //Assert.assertThrows( tham số 1: ngoại lệ muốn so sánh, đoạn code chạy văng ra ngoài runnable);
        Assert.assertThrows(IllegalArgumentException.class,  // liệu rằng có ném về 1 class thuộc lớp interface này không
                () -> MathUtil.getFactorial(-5)               
                );
        //MathUtil.getFactorial(-5); // hàm @Test hay hàm getF() này chạy sẽ phải ném về ngoại lệ NumberFormat
    
    }
    // cách 3, xem hàm có ném về ngoại lệ hay không khi input sai
    
    @Test
    public void testGetFactorialGivenWrongtArgumentThrowsExceptionTryCatch(){
        try {
            MathUtil.getFactorial(-5); // hàm @Test hay hàm getF() này chạy sẽ phải ném về ngoại lệ NumberFormat
        } catch (Exception e) {
            // bắt try catch là Junit sẽ ra xanh do đã chủ động kiểm soát ngoại lệ
            // nhưng ko chắc ngoại lệ mình cần có xuất hiện hay không?
            // có đoạn code kiểm soát đúng ngoại lệ IlligumentException xuất hiện
            Assert.assertEquals("Invalid argument. N must be between 0 -> 20",e.getMessage()); 
            // getMassage có tất cả thông tin ngoại lệ bao gồm cả thông tin mô tả ngoại lệ
        }
    
    }
}
